package com.arsari.inventoryapp;

/*
 * Arturo Santiago-Rivera
 * CS-360-X6386 Mobile Architect & Programming 21EW6
 * Southern New Hampshire University
 * August 2021
 */

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.atomic.AtomicReference;


public class AddItemActivity extends AppCompatActivity {

    String EmailHolder, DescHolder, QtyHolder;
    TextView UserEmail;
    ImageButton IncreaseQty, DecreaseQty;
    EditText ItemQtyValue, ItemDescValue;
    Button CancelButton, AddItemButton;
    SQLiteDatabase sqLiteDatabaseObj;
    String SQLiteDataBaseQueryHolder ;
    ItemSQLiteHelper sqLiteHelper;
    Boolean EmptyDescHolder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_additem);

        // Initiate buttons, textViews, and editText variables
        UserEmail = findViewById(R.id.textViewLoggedUser);
        ItemDescValue = findViewById(R.id.editTextItemDescription);
        IncreaseQty = findViewById(R.id.itemQtyIncrease);
        DecreaseQty = findViewById(R.id.itemQtyDecrease);
        ItemQtyValue = findViewById(R.id.editTextItemQuantity);
        CancelButton = findViewById(R.id.cancelButton);
        AddItemButton = findViewById(R.id.addItemButton);
        sqLiteHelper = new ItemSQLiteHelper(this);

        AtomicReference<Intent> intent = new AtomicReference<>(getIntent());

        // Receiving user email send by ItemsActivity
        EmailHolder = intent.get().getStringExtra(ItemsActivity.UserEmail);

        // Setting user email on textViewLoggedUser
        UserEmail.setText(getString(R.string.logged_user, EmailHolder));

        // Adding click listener to itemQtyIncrease button
        IncreaseQty.setOnClickListener(view -> {
            int input = 0, total;

            String value = ItemQtyValue.getText().toString().trim();

            if (!value.isEmpty()) {
                input = Integer.parseInt(value);
            }

            total = input + 1;
            ItemQtyValue.setText(String.valueOf(total));
        });

        // Adding click listener to itemQtyDecrease button
        DecreaseQty.setOnClickListener(view -> {
            int input, total;

            String value = ItemQtyValue.getText().toString().trim();

            if (value.isEmpty() || value.equals("0")) {
                Toast.makeText(AddItemActivity.this, "Item Quantity is Zero", Toast.LENGTH_LONG).show();
            } else {
                input = Integer.parseInt(value);
                total = input - 1;
                ItemQtyValue.setText(String.valueOf(total));
            }
        });

        // Adding click listener to cancelButton
        CancelButton.setOnClickListener(view -> {
            // Going back to ItemsActivity after cancel adding item
            intent.set(new Intent());
            setResult(0, intent.get());
            finish();
        });

        // Adding click listener to addItemButton and pass data to ItemsActivity
        AddItemButton.setOnClickListener(view -> {
            // Create SQLite database if doesn't exists
            SQLiteDataBaseBuild();
            // Create SQLite table if doesn't exists
            SQLiteTableBuild();
            // Checking item description is not empty
            CheckEditTextNotEmpty();
            // Insert data into items database
            InsertDataInDatabase();
        });
    }

    // SQLite database build function
    public void SQLiteDataBaseBuild(){
        sqLiteDatabaseObj = openOrCreateDatabase(ItemSQLiteHelper.DATABASE_NAME, Context.MODE_PRIVATE, null);
    }

    // SQLite table build function
    public void SQLiteTableBuild() {
        sqLiteDatabaseObj.execSQL("CREATE TABLE IF NOT EXISTS " + ItemSQLiteHelper.TABLE_NAME + "(" + ItemSQLiteHelper.Table_Column_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " + ItemSQLiteHelper.Table_Column_1_UserEmail + " VARCHAR, " + ItemSQLiteHelper.Table_Column_2_Description + " VARCHAR, " + ItemSQLiteHelper.Table_Column_3_Quantity + " VARCHAR);");
    }

    // Insert item data into database and send data to ItemsActivity
    public void InsertDataInDatabase() {
        if (EmptyDescHolder) {
            // SQLite query to insert data into table
            SQLiteDataBaseQueryHolder = "INSERT INTO "+ ItemSQLiteHelper.TABLE_NAME+" (useremail, description, quantity) VALUES('"+EmailHolder+"', '"+DescHolder+"', '"+QtyHolder+"');";
            // Execute query
            sqLiteDatabaseObj.execSQL(SQLiteDataBaseQueryHolder);
            // Close SQLite database object
            sqLiteDatabaseObj.close();
            // Display toast message after insert in table
            Toast.makeText(AddItemActivity.this,"Item Added Successfully", Toast.LENGTH_LONG).show();
            // Going back to ItemsActivity with item data result
            ItemInfo itemInfo = new ItemInfo();
            itemInfo.setItemDescription(DescHolder);
            itemInfo.setItemQty(QtyHolder);

            Intent result = new Intent();
            Bundle info = new Bundle();
            info.putSerializable("InfoBundle", itemInfo);
            result.putExtras(info);
            setResult(1, result);
            // Close AddItemActivity
            finish();
        } else {
            // Display toast message if item description is empty and focus the field
            ItemDescValue.requestFocus();
            Toast.makeText(AddItemActivity.this,"Item Description is Empty", Toast.LENGTH_LONG).show();
        }
    }

    // Checking item description is not empty
    public void CheckEditTextNotEmpty() {
        // Getting value from fields and storing into string variable
        DescHolder = ItemDescValue.getText().toString().trim();
        QtyHolder = ItemQtyValue.getText().toString().trim();

        if (DescHolder.isEmpty() || QtyHolder.isEmpty()) {
            EmptyDescHolder = false;
        } else {
            EmptyDescHolder = true;
        }
    }

}