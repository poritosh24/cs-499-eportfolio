package com.arsari.inventoryapp;

/*
 * Arturo Santiago-Rivera
 * CS-360-X6386 Mobile Architect & Programming 21EW6
 * Southern New Hampshire University
 * August 2021
 */

import java.io.Serializable;


// Set and get of item data
public class ItemInfo implements Serializable {

    String description;
    String quantity;

    public String getItemDescription() {
        return description;
    }
    public void setItemDescription(String description) {
        this.description = description;
    }
    public String getItemQty() {
        return quantity;
    }
    public void setItemQty(String quantity) {
        this.quantity = quantity;
    }
}
